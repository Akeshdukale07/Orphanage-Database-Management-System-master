# Orphanage Database Management System

This is a web oriented project on Orphanage Management System which keeps record of all the orphans. This is a simple project which uses PHP for connection and MySQL for storing records in database. I have also provided a feature to add a payment gateway to accept donations . 

Admin login

username : admin
pass : admin

