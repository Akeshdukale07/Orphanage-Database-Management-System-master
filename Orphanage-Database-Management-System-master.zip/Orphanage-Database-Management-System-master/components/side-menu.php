<!-- Left menu -->
<div class="four wide column" id="example1">
    <div class="ui secondary vertical pointing menu">
        <a class="item <?php echo ($_SERVER['PHP_SELF'] == "/orphan/index.php" ? "active" : "");?>" href="index.php">Home</a>
        <a class="item <?php echo ($_SERVER['PHP_SELF'] == "/orphan/child-gallery-sponsored.php" ? "active" : "");?>" href="child-gallery-sponsored.php">Child Gallery</a>
        <a class="item <?php echo ($_SERVER['PHP_SELF'] == "/orphan/program.php" ? "active" : "");?>" href="program.php">Programs</a>
        <a class="item <?php echo ($_SERVER['PHP_SELF'] == "/orphan/donation.php" ? "active" : "");?>" href="donation.php">Donation</a>
        <a class="item <?php echo ($_SERVER['PHP_SELF'] == "/orphan/photo-gallery.php" ? "active" : "");?>" href="photo-gallery.php">Photo Gallery</a>
        <a class="item <?php echo ($_SERVER['PHP_SELF'] == "/orphan/feedback-form.php" ? "active" : "");?>" href="feedback-form.php">FeedBack</a>
        <a class="item <?php echo ($_SERVER['PHP_SELF'] == "/orphan/contact-us.php" ? "active" : "");?>" href="contact-us.php">Contact Us</a>
    </div>
</div>